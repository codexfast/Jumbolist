<script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="{{asset("/sb/dist/js/scripts.js")}}"></script>
<script src="{{url('/js/fix-custom-select-input.js')}}"></script>

