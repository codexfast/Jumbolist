<?php $__env->startSection('title', 'Doações'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row">
        <div class="col">
            <h4 class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-muted">Faça uma Doação</span>
                <i class="fas fa-star" style="color: #fbc52d;"></i>
              </h4>
              <ul class="list-group mb-3">
                <?php $__currentLoopData = $donates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex justify-content-between lh-condensed">
                  <a class="btn btn-dark text-light" href="<?php echo e($donate->link); ?>">Doar</a>
                  <span class="text-muted">R$ <?php echo e(str_replace('.', ',', $donate->amount)); ?></span>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </ul>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Dev\PHP\Jumbolist\resources\views/donates.blade.php ENDPATH**/ ?>