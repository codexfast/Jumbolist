<script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset("/sb/dist/js/scripts.js")); ?>"></script>
<script src="<?php echo e(url('/js/fix-custom-select-input.js')); ?>"></script>

<?php /**PATH C:\Users\User\Desktop\Dev\PHP\Jumbolist\resources\views/partials/sb-js.blade.php ENDPATH**/ ?>