
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e($app_name); ?></title>

    <!-- Bootstrap core CSS -->
  <link href="https://getbootstrap.com/docs/4.4/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>

  <script>
    let states_cities = <?= isset($states_cities) ? $states_cities : 'null' ?>;
    let states_cities_with_unit = <?= isset($states_cities_with_unit) ? $states_cities_with_unit : 'null' ?>;
</script>

<meta name="theme-color" content="#563d7c">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .Montserrat {
        font-family: 'Montserrat', sans-serif;
      }
    </style>

  </head>
  <body class="bg-light pt-5 mt-5">
    <nav class="navbar navbar-expand-lg navbar-light bg-light mb-4 fixed-top">
      <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('')); ?>">
          <img src="<?php echo e(url('/favicon.ico')); ?>"  width="16" height="16">
          <?php echo e($app_name); ?>

        </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <?php if($uri == ''): ?>
            <a class="nav-link active" href="<?php echo e(url('')); ?>">Inicial</a>
            <?php else: ?>
            <a class="nav-link" href="<?php echo e(url('')); ?>">Inicial</a>
            <?php endif; ?>
          </li>
          <li class="nav-item">
            <?php if($uri == 'buscar'): ?>
            <a class="nav-link active" href="<?php echo e(url('/buscar')); ?>">Buscar</a>
            <?php else: ?>
            <a class="nav-link" href="<?php echo e(url('/buscar')); ?>">Buscar</a>

            <?php endif; ?>
          </li>
          <li class="nav-item">
            <?php if($uri == 'contribuir'): ?>
            <a class="nav-link active" href="<?php echo e(url('/contribuir')); ?>">Contribuir</a>
            <?php else: ?>
            <a class="nav-link" href="<?php echo e(url('/contribuir')); ?>">Contribuir</a>

            <?php endif; ?>
          </li>
          <li class="nav-item">
            <?php if($uri == 'doacoes'): ?>
            <a class="nav-link active" href="<?php echo e(url('/doacoes')); ?>">Doações</a>
            <?php else: ?>
            <a class="nav-link" href="<?php echo e(url('/doacoes')); ?>">Doações</a>
            <?php endif; ?>

          </li>
          <li class="nav-item">
            <?php if($uri == 'sobre'): ?>
            <a class="nav-link active" href="<?php echo e(url('/sobre')); ?>">Sobre</a>
            <?php else: ?>
            <a class="nav-link" href="<?php echo e(url('/sobre')); ?>">Sobre</a>
            <?php endif; ?>
          </li>
        </ul>
      </div>
      </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>
    <footer class="my-4 pt-4 text-muted text-center text-small">
      <p class="mb-1">&copy; <?= date("Y"); ?> <?php echo e($app_name); ?> - <a href="mailto:<?php echo e($email); ?>" class="text-muted" target="_top"><?php echo e($email); ?></a></p>
    </footer>
  <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

  <script src="<?php echo e(url('/js/main.js')); ?>"></script>
  <script src="<?php echo e(url('/js/fix-custom-select-input.js')); ?>"></script>

  </body>
</html>
<?php /**PATH C:\Users\User\Desktop\Dev\PHP\Jumbolist\resources\views/index.blade.php ENDPATH**/ ?>