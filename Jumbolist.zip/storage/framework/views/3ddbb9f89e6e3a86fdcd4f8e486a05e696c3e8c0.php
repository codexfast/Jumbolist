<?php $__env->startSection('title', 'Início'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-2">
  <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
<div class="carousel-inner">
  <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($loop->index == 0): ?>
    <div class="carousel-item active">
    <?php else: ?>
    <div class="carousel-item">    
    <?php endif; ?>
      <img src="<?php echo e(url('/banners/'.$banner->banner)); ?>" class="d-block w-100" alt="<?php echo e($banner->banner); ?>">
  </div>      
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>

<div class="container">
    <div class=" text-center">
      <img class="d-block mx-auto mb-4" src="<?php echo e(url('/logo.png')); ?>" alt="" width="72" height="72">
      <h2>Jumbolist</h2>
      <p class="lead">Dificuldades em obter lista de materiais para unidades prisionais? busque aqui na maior plataforma de lista de jumbo, você tambem pode ajudar mandado listas ou fazendo doações</p>
    </div>
  
    <div class="embed-responsive embed-responsive-16by9 mx-auto" style="max-width: 600px;">
        <iframe  src="https://www.youtube.com/embed/FWH0crWfUlk?controls=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"></iframe>
    </div>
    <div class="mt-3">
      <p class="lead text-center">Se a nossa plataforma foi util a você deixe seu like e realize uma doação para mante-la sempre online.</p>
    </div>
    
  </div>
  <div class="container">

    <div class="row">
        <div class="col">
            <h4 class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-muted">Faça uma Doação</span>
                <i class="fas fa-star" style="color: #fbc52d;"></i>
              </h4>
              <ul class="list-group mb-3">
                <?php $__currentLoopData = $donates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex justify-content-between lh-condensed">
                  <a class="btn btn-dark text-light" href="<?php echo e($donate->link); ?>">Doar</a>
                  <span class="text-muted">R$ <?php echo e(str_replace('.', ',', $donate->amount)); ?></span>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </ul>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Dev\PHP\Jumbolist\resources\views/home.blade.php ENDPATH**/ ?>