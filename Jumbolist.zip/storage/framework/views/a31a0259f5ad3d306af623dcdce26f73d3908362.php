<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset("/sb/dist/assets/demo/datatables-demo.js")); ?>"></script>
<?php /**PATH C:\Users\User\Desktop\Dev\PHP\Jumbolist\resources\views/partials/sb-datatable-js.blade.php ENDPATH**/ ?>