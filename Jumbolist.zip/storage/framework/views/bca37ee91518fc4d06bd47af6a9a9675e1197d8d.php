<?php $__env->startComponent('mail::message'); ?>

# Nova registrada

Uma nova unidade foi registrada na cidade <?php echo e($city); ?>-<?php echo e($initials); ?>,
cheque agora clicando no botão abaixo.

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Checar
<?php echo $__env->renderComponent(); ?>

Obrigado,<br>
<?php echo e($app_name); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\User\Desktop\Dev\PHP\Jumbolist\resources\views/emails/notify.blade.php ENDPATH**/ ?>