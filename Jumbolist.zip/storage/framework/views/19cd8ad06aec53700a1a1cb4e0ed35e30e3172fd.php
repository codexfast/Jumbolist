<script src="<?php echo e(asset("/bower_components/admin-lte/plugins/jquery/jquery.min.js")); ?>"></script>
<script src="<?php echo e(asset("/bower_components/admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js")); ?>"></script>
<script src="<?php echo e(asset("/bower_components/admin-lte/dist/js/adminlte.min.js")); ?>"></script>
<?php /**PATH C:\Users\User\Desktop\Dev\PHP\Jumbolist\resources\views/partials/admin-lte-js.blade.php ENDPATH**/ ?>