;

<?php $__env->startSection('title', 'Banners -'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="mt-4">Banners</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active">Banners</li>
</ol>

<div class="row">
    <div class="col-xl-12">
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-plus mr-1"></i>Adicione banner</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(url('/admin/add-banner')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                          <span class="input-group-text" id="inputGroupFileAddon01">
                              <i class="fas fa-images"></i>
                          </span>
                        </div>
                        <div class="custom-file">
                          <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" name="banner">
                          <label class="custom-file-label" for="inputGroupFile01">Escolha o arquivo</label>
                        </div>
                      </div>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    </form>
            </div>
        </div>
    </div>
    <div class="col-xl-12">
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-images mr-1"></i>Lista de Banners</div>
            <div class="card-body">

                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <div class="card mb-3">
                    <img src="<?php echo e(url('/banners/' . $banner->banner)); ?>" class="card-img-top" alt="<?php echo e($banner->banner); ?>">
                    <div class="card-body">
                      <h5 class="card-title">Banner #<?php echo e($loop->index + 1); ?></h5>
                      <a href="<?php echo e(url('/admin/remove-banner/' . $banner->id)); ?>" class="btn btn-danger">Deletar</a>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Dev\PHP\Jumbolist\resources\views/banners.blade.php ENDPATH**/ ?>