# Lista de Jumbos
### Descrição
Ajudar na listagem de alimentos e materiais permitidos aos internos(as)

### Funcões da plataforma
- Distribuir listas de alimentos e materiais de acordo com unidade prisional
- Permitir upload de listas no formato (pdf, jpg, png) e relacionados
- Gerenciar listas no painel admin
- Gerenciar listas comunitárias (aceitar ou não)
- Notificação via e-mail para usuarios que permitirem recebimento de atualizaçoes das listas interessadas
- Receber doações via mercado pago


### Observações
- Ter publicidade & video informativo
- Ter rota para iframe (será incorporado em uma página existente)
- Ter rota sobre (Gerenciada pelo admin)
- Ter rota busca
